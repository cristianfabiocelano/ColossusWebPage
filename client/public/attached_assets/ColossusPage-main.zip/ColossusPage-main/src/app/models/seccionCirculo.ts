export class SeccionCirculo {
    titulo: string = '';
    descripcion: string = '';
    nombreBoton: string = '';
    estiloCirculo: estiloCirculo = estiloCirculo.estiloPrimario;

    constructor (){
        this.titulo="";
        this.descripcion="";
        this.nombreBoton="Conocer más";
        this.estiloCirculo= estiloCirculo.estiloPrimario;
    }
}

export enum estiloCirculo {
    estiloPrimario,
    estiloSecundario,
    estiloTerciario
}

