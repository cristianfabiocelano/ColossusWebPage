import { Component, OnInit, Input } from '@angular/core';
import { SeccionCirculo } from 'src/app/models/seccionCirculo';

@Component({
  selector: 'app-home-colossus',
  templateUrl: './home-colossus.component.html',
  styleUrls: ['./home-colossus.component.scss']
})
export class HomeColossusComponent implements OnInit {
  @Input() seccionContacto: SeccionCirculo = new SeccionCirculo();
  @Input() seccionNosotros: SeccionCirculo = new SeccionCirculo();

  constructor() { }

  ngOnInit(): void {
    this.seccionContacto.titulo = "Contactenos";
    this.seccionContacto.descripcion = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam corporis assumenda doloremque exercitationem distinctio optio quae neque nihil quibusdam";
    this.seccionContacto.nombreBoton = "Empezemos a trabajar";
    // this.seccionContacto.estiloCirculo = estiloCirculo.estiloPrimario;

    this.seccionNosotros.titulo = "Nosotros";
    this.seccionNosotros.descripcion = "¡Somos Colossus una empresa que brinda soluciones tecnologicas! Queres saber mas sobre nosotros y sus fundadores";
    this.seccionNosotros.nombreBoton = "Conocer más";
    // this.seccionNosotros.estiloCirculo = estiloCirculo.estiloSecundario;

  }

}
