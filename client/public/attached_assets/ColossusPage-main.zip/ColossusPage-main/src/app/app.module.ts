import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { ReactiveFormsModule } from '@angular/forms'
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeColossusComponent } from './pages/home-colossus/home-colossus.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { ContactComponent } from './components/contact/contact.component';
import { TecnologyComponent } from './components/tecnology/tecnology.component';
import { CardsHorizontalyComponent } from './components/cards-horizontaly/cards-horizontaly.component';
import { NosotrosComponent } from './components/nosotros/nosotros.component';
import { CarouselComponent } from './components/carousel/carousel.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeColossusComponent,
    NavbarComponent,
    FooterComponent,
    ContactComponent,
    TecnologyComponent,
    CardsHorizontalyComponent,
    NosotrosComponent,
    CarouselComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
