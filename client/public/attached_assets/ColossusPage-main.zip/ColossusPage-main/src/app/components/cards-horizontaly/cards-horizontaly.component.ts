import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cards-horizontaly',
  templateUrl: './cards-horizontaly.component.html',
  styleUrls: ['./cards-horizontaly.component.scss']
})
export class CardsHorizontalyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
