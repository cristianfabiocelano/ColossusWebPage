import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  public contactForm: FormGroup | undefined;

  constructor(private fb: FormBuilder,) { }

  ngOnInit(): void {

    this.contactForm = this.fb.group({
      'nombre': ['', [Validators.required]],
      'email': ['', [Validators.required]],
      'mensaje': ['', [Validators.required]],
    });
  }

  onContact() {
    const { nombre, email, mensaje } = this.contactForm?.value;
    console.log(nombre, email, mensaje );
    //3 soluciones
    //nodemailer (Esto necesitas un back puede ser con nodejs con ese paquete y aca generas un servicio y le pegas a eso) 
    //o mailto (Este camino es solo HTML pero es malo/feo) (Te abre el gestor de email que tengas instalado en tu pc)
    //mandamos un wpp con una plantilla de los datos enviados a algun celular y que de ahi armemos algun bot o algo automatizado que envie el email

  }
}
